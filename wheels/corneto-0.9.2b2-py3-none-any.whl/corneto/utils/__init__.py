from corneto.utils._attr import Attr, Attributes

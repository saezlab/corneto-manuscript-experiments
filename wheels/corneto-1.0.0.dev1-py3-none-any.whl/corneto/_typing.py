from typing import Tuple, Union

StrOrInt = Union[str, int]
TupleSIF = Tuple[str, int, str]
